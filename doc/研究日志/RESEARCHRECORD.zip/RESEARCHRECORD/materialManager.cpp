#include <stdio.h>
#include <iostream>
#include <string>

#define objCount 2

using namespace std;

typedef struct objClass {
	int num;
	string topic;
	string info;
}objClass;

void showInit(int count, objClass object[]) {
	cout << "\n\t****************  Welcome to ESLAB  ****************\n\n";
	cout << "\t****************************************************\n\n";
	for (int i = 0; i < count; ++i) {
		cout << "\t\t" << object[i].num << " : " << object[i].topic << endl;
	}
	cout << "\n\t****************************************************\n\n";
}

void showInfo(objClass object) {
	cout << "\n\t****************  Welcome to ESLAB  ****************\n\n";
	cout << "\t****************************************************\n\n";
	cout << "\t\t" << object.topic << ":\n\t\t    " << object.info;
	cout << "\n\n\t****************************************************\n\n";
}

int main() {
	int objNo;
	objClass obj[objCount];
	for (int i = 0; i < objCount; ++i) {
		obj[i].num = i;
	}
	obj[0].topic = "a";
	obj[0].info = "aaa";
	obj[1].topic = "b";
	obj[1].info = "bbb";
	showInit(objCount, obj);
	while (1) {
		cout << "请输入需要查询的物品编号: ";
		cin >> objNo;
		cout << endl;
		if (objNo == -1)
			break;
		else
			showInfo(obj[objNo]);
	}
	return 0;
}

