#!env python

def showInit(obj, count):
	print '\n\t****************  Welcome to ESLAB  ****************\n\n',
	print '\t****************************************************\n'
	for i in range(0, count):
		print '\t\t',
		print obj['num'][i],
		print ':',
		print obj['topic'][i]
	print '\n\t****************************************************\n'

def showInfo(obj, objNo):
	print '\n\t****************  Welcome to ESLAB  ****************\n\n',
	print '\t****************************************************\n\n',
	print '\t\t',
	print obj['topic'][objNo],
	print ':\n\t\t    ',
	print obj['info'][objNo],
	print '\n\n\t****************************************************\n'

objCount = 2
numArr = [i for i in range(0, objCount)]
topicArr = ['a', 'b']
infoArr = ['aaa', 'bbb']
obj = {'num': numArr, 'topic': topicArr, 'info': infoArr}

showInit(obj, objCount)

objNo = input('Input: ')
while objNo != -1:
	showInfo(obj, objNo)
	objNo = input('Input: ')

